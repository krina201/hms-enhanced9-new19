<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('approval_workflows', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('applies_to'); // 'requisition'
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
        Schema::create('approval_steps', function (Blueprint $table) {
            $table->id();
            $table->foreignId('approval_workflow_id')->constrained('approval_workflows')->cascadeOnDelete();
            $table->unsignedInteger('level');
            $table->string('role_name');
            $table->unsignedInteger('sla_hours')->nullable();
            $table->timestamps();
        });
        Schema::table('requisitions', function (Blueprint $table) {
            $table->foreignId('workflow_id')->nullable()->constrained('approval_workflows')->nullOnDelete();
        });
        Schema::create('requisition_approvals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('requisition_id')->constrained('requisitions')->cascadeOnDelete();
            $table->foreignId('approval_step_id')->constrained('approval_steps')->cascadeOnDelete();
            $table->string('status');
            $table->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->text('note')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void {
        Schema::table('requisitions', function (Blueprint $table) { $table->dropConstrainedForeignId('workflow_id'); });
        Schema::dropIfExists('requisition_approvals');
        Schema::dropIfExists('approval_steps');
        Schema::dropIfExists('approval_workflows');
    }
};
