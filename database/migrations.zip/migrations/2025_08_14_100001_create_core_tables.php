<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('suppliers', function(Blueprint $t){ $t->id(); $t->string('name'); $t->timestamps(); });
        Schema::create('locations', function(Blueprint $t){ $t->id(); $t->string('name'); $t->timestamps(); });
        Schema::create('inventory_items', function(Blueprint $t){ $t->id(); $t->string('name'); $t->string('unit')->nullable(); $t->unsignedInteger('reorder_level')->default(0); $t->timestamps(); });
        Schema::create('purchase_orders', function(Blueprint $t){
            $t->id(); $t->string('order_no')->unique();
            $t->foreignId('supplier_id')->nullable()->constrained('suppliers')->nullOnDelete();
            $t->date('order_date')->nullable();
            $t->date('expected_date')->nullable();
            $t->decimal('grand_total',12,2)->default(0);
            $t->string('status')->default('DRAFT');
            $t->timestamps();
        });
        Schema::create('purchase_order_items', function(Blueprint $t){
            $t->id(); 
            $t->foreignId('purchase_order_id')->constrained('purchase_orders')->cascadeOnDelete();
            $t->foreignId('inventory_item_id')->constrained('inventory_items')->restrictOnDelete();
            $t->decimal('qty',12,3); $t->decimal('unit_price',12,2)->default(0);
            $t->decimal('tax_rate',6,2)->default(0); $t->decimal('discount',12,2)->default(0);
            $t->timestamps();
        });
        Schema::create('goods_receipts', function(Blueprint $t){
            $t->id(); $t->string('grn_no')->unique();
            $t->foreignId('purchase_order_id')->nullable()->constrained('purchase_orders')->nullOnDelete();
            $t->foreignId('location_id')->nullable()->constrained('locations')->nullOnDelete();
            $t->date('grn_date')->nullable(); $t->string('received_by')->nullable();
            $t->timestamp('posted_at')->nullable(); $t->timestamps();
        });
        Schema::create('goods_receipt_items', function(Blueprint $t){
            $t->id(); 
            $t->foreignId('goods_receipt_id')->constrained('goods_receipts')->cascadeOnDelete();
            $t->foreignId('inventory_item_id')->constrained('inventory_items')->restrictOnDelete();
            $t->string('batch_no')->nullable(); $t->date('expiry_date')->nullable();
            $t->decimal('received_qty',12,3)->default(0); $t->decimal('unit_price',12,2)->nullable();
            $t->timestamps();
        });
        Schema::create('stock_batches', function(Blueprint $t){
            $t->id(); 
            $t->foreignId('inventory_item_id')->constrained('inventory_items')->restrictOnDelete();
            $t->foreignId('location_id')->constrained('locations')->restrictOnDelete();
            $t->string('batch_no'); $t->date('expiry_date')->nullable();
            $t->decimal('qty_on_hand',12,3)->default(0);
            $t->timestamps();
            $t->index(['inventory_item_id','location_id','batch_no']);
        });
        Schema::create('stock_movements', function(Blueprint $t){
            $t->id();
            $t->foreignId('inventory_item_id')->constrained('inventory_items')->restrictOnDelete();
            $t->foreignId('stock_batch_id')->nullable()->constrained('stock_batches')->nullOnDelete();
            $t->foreignId('location_id')->constrained('locations')->restrictOnDelete();
            $t->string('type'); $t->decimal('qty',12,3);
            $t->string('ref_type')->nullable(); $t->unsignedBigInteger('ref_id')->nullable();
            $t->json('meta')->nullable(); $t->timestamps();
        });
        Schema::create('goods_returns', function(Blueprint $t){
            $t->id(); $t->string('return_no')->unique();
            $t->date('return_date')->nullable();
            $t->foreignId('location_id')->nullable()->constrained('locations')->nullOnDelete();
            $t->string('reason')->nullable(); $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
        });
        Schema::create('goods_return_items', function(Blueprint $t){
            $t->id();
            $t->foreignId('goods_return_id')->constrained('goods_returns')->cascadeOnDelete();
            $t->foreignId('stock_batch_id')->constrained('stock_batches')->restrictOnDelete();
            $t->foreignId('inventory_item_id')->constrained('inventory_items')->restrictOnDelete();
            $t->decimal('qty',12,3); $t->timestamps();
        });
        Schema::create('approval_workflows', function(Blueprint $t){
            $t->id(); $t->string('name'); $t->string('applies_to'); $t->boolean('is_active')->default(true); $t->timestamps();
        });
        Schema::create('approval_steps', function(Blueprint $t){
            $t->id(); $t->foreignId('approval_workflow_id')->constrained('approval_workflows')->cascadeOnDelete();
            $t->unsignedInteger('level'); $t->string('role_name'); $t->unsignedInteger('sla_hours')->default(24); $t->timestamps();
        });
        Schema::create('requisitions', function(Blueprint $t){
            $t->id(); $t->string('req_no')->nullable(); $t->date('req_date')->nullable();
            $t->foreignId('supplier_id')->nullable()->constrained('suppliers')->nullOnDelete();
            $t->string('status')->default('DRAFT'); $t->foreignId('workflow_id')->nullable()->constrained('approval_workflows')->nullOnDelete();
            $t->unsignedBigInteger('requested_by')->nullable(); $t->timestamps();
        });
        Schema::create('requisition_approvals', function(Blueprint $t){
            $t->id();
            $t->foreignId('requisition_id')->constrained('requisitions')->cascadeOnDelete();
            $t->foreignId('approval_step_id')->constrained('approval_steps')->cascadeOnDelete();
            $t->string('status')->default('PENDING');
            $t->unsignedBigInteger('approved_by')->nullable(); $t->timestamp('approved_at')->nullable();
            $t->text('note')->nullable(); $t->timestamps();
        });
        Schema::create('activity_logs', function(Blueprint $t){
            $t->id(); $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->string('action'); $t->string('subject_type')->nullable(); $t->unsignedBigInteger('subject_id')->nullable();
            $t->json('changes')->nullable(); $t->timestamps();
        });
    }
    public function down(): void {
        foreach (['activity_logs','requisition_approvals','requisitions','approval_steps','approval_workflows','goods_return_items','goods_returns','stock_movements','stock_batches','goods_receipt_items','goods_receipts','purchase_order_items','purchase_orders','inventory_items','locations','suppliers'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
