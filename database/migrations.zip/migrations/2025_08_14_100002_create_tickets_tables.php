<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('tickets', function(Blueprint $t){
            $t->id();
            $t->string('subject');
            $t->text('description')->nullable();
            $t->string('status')->default('OPEN');
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->foreignId('assigned_to')->nullable()->constrained('users')->nullOnDelete();
            $t->unsignedInteger('sla_hours')->default(24);
            $t->timestamp('due_at')->nullable();
            $t->timestamp('closed_at')->nullable();
            $t->timestamps();
        });
        Schema::create('ticket_comments', function(Blueprint $t){
            $t->id();
            $t->foreignId('ticket_id')->constrained('tickets')->cascadeOnDelete();
            $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->text('body');
            $t->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('ticket_comments');
        Schema::dropIfExists('tickets');
    }
};
